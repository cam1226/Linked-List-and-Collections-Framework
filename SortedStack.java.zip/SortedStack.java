package com.example;

import java.util.Stack;
import java.util.Collections;
import java.util.Scanner;

/**
 * The SortedStack program reads a list of integers from the input, stores them in a Stack,
 * and sorts them in ascending order. This program demonstrates the use of Java Collections and
 * utility methods for sorting and reading user input.
 *
 * <p>Design Details:
 * <ul>
 *   <li>Scanner is used for reading input from the console.</li>
 *   <li>Stack is used to store the list of integers.</li>
 *   <li>Collections.sort is used to sort the stack.</li>
 *   <li>Methods are extracted to demonstrate code reuse and modularity.</li>
 * </ul>
 * </p>
 *
 * <p>To run this program from the command line:</p>
 * <pre>
 *   javac com/example/SortedStack.java
 *   java com.example.SortedStack
 * </pre>
 *
 * <p>To generate Javadoc for this program:</p>
 * <pre>
 *   javadoc -d doc com/example/*.java
 * </pre>
 */
public class SortedStack {

    /**
     * The main method reads integers from standard input and prints the sorted stack.
     *
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        // Read integers from standard input
        Stack<Integer> numbers = readInput();

        // Sort the stack
        sortStack(numbers);

        // Print the sorted stack
        printStack(numbers);
    }

    /**
     * Reads integers from standard input until 'end' is entered.
     *
     * @return A stack of integers entered by the user.
     */
    public static Stack<Integer> readInput() {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> numbers = new Stack<>();

        System.out.println("Enter integers (type 'end' to finish):");

        while (scanner.hasNext()) {
            String input = scanner.next();
            if (input.equalsIgnoreCase("end")) {
                break;
            }
            try {
                numbers.push(Integer.parseInt(input));
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter an integer or 'end' to finish.");
            }
        }

        scanner.close();
        return numbers;
    }

    /**
     * Sorts the given stack of integers in ascending order.
     *
     * @param numbers The stack of integers to be sorted.
     */
    public static void sortStack(Stack<Integer> numbers) {
        Collections.sort(numbers);
    }

    /**
     * Prints the sorted stack of integers.
     *
     * @param numbers The sorted stack of integers.
     */
    public static void printStack(Stack<Integer> numbers) {
        System.out.println("Sorted stack: " + numbers);
    }
}
